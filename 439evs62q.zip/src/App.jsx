import React from 'react'
import Quiz from './components/Quiz'

const App = () => {
  return (
    <>
      <Quiz/>
    </>
  )
}

export default App